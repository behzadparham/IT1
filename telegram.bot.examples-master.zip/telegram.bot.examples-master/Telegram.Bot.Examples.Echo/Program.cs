﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using Telegram.Bot.Args;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.InlineQueryResults;
using Telegram.Bot.Types.InputMessageContents;
using Telegram.Bot.Types.ReplyMarkups;

namespace Telegram.Bot.Examples.Echo
{
    class Program
    {
        private static readonly TelegramBotClient Bot = new TelegramBotClient("263694111:AAEYL4neg_xgWmao1iPhUzrN-YKnZwaM5sE");

        static void Main(string[] args)
        {
            Bot.OnCallbackQuery += BotOnCallbackQueryReceived;
            Bot.OnMessage += BotOnMessageReceived;
            Bot.OnMessageEdited += BotOnMessageReceived;
            Bot.OnInlineResultChosen += BotOnChosenInlineResultReceived;
            Bot.OnReceiveError += BotOnReceiveError;

            var me = Bot.GetMeAsync().Result;

            Console.Title = me.Username;
            Console.WriteLine(me.FirstName);
            Bot.StartReceiving();
            Console.ReadLine();
            Bot.StopReceiving();
        }
        
        private static void BotOnReceiveError(object sender, ReceiveErrorEventArgs receiveErrorEventArgs)
        {
            Debugger.Break();
        }

        private static void BotOnChosenInlineResultReceived(object sender, ChosenInlineResultEventArgs chosenInlineResultEventArgs)
        {
            Console.WriteLine("Received choosen inline result: {chosenInlineResultEventArgs.ChosenInlineResult.ResultId}");
        }

        private static async void BotOnMessageReceived(object sender, MessageEventArgs messageEventArgs)
        {
            var message = messageEventArgs.Message;
            Console.WriteLine(
                           "Msg from {0} {1} ({2}) at {4}: {3}",
                           message.From.FirstName,
                           message.From.LastName,
                            message.From.Username,
                            message.Text,
                           message.Date);
            if (message == null || message.Type != MessageType.TextMessage) return;

            else if (message.Text.StartsWith("/start"))
            {
                await Bot.SendTextMessageAsync(message.Chat.Id, "سلام من بات فروشگاه mastercode.ir هستم");
                await Bot.SendTextMessageAsync(message.Chat.Id, "جهت دیدن دروس و پروژه /help  را تایپ کن");
            }
else if (message.Text.StartsWith("/Arificial-Intellingence")) 
            {
                await Bot.SendChatActionAsync(message.Chat.Id, ChatAction.Typing);

                var keyboard = new InlineKeyboardMarkup(new[]
                {
                    
                        new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="پروژه8وزیر ",
                           Url="https://fa.wikipedia.org/wiki/%D9%85%D8%B3%D8%A6%D9%84%D9%87_%DA%86%D9%86%D8%AF_%D9%88%D8%B2%DB%8C%D8%B1"
                            }
                        },
                        new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="خرید پروژه پیاده سازی باژنتیک   ",
                           Url="http://mastercode.ir/payment.cshtml"
                            }
                        },
                          new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="پروژه معمای ۱۲ ",
                           Url="http://kahu.ir/question/3418/%D9%85%D8%B9%D9%85%D8%A7%DB%8C-%DB%8C%D8%A7%D9%81%D8%AA%D9%86-%D8%B3%DA%A9%D9%87-%D8%AA%D9%82%D9%84%D8%A8%DB%8C-%D8%A7%D8%B2-%D8%A8%DB%8C%D9%86-%DB%B1%DB%B2-%D8%B3%DA%A9%D9%87-%D9%88-%D8%A7%DB%8C%D9%86-%DA%A9%D9%87-%D8%B3%D8%A8%DA%A9-%D8%AA%D8%B1-%DB%8C%D8%A7-%D8%B3%D9%86%DA%AF%DB%8C%D9%86-%D8%AA%D8%B1-%D8%A7%D8%B3%D8%AA/"
                            }
                        },
                        new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="خرید پروژه در محیط وینفرم",
                           Url="http://mastercode.ir/payment.cshtml"
                            }
                        },
                        
                });

                await Task.Delay(500);

                await Bot.SendTextMessageAsync(message.Chat.Id, "پروژه های موجود",
                    replyMarkup: keyboard);
            }
            else if (message.Text.StartsWith("/Multimedia"))
            {
                await Bot.SendChatActionAsync(message.Chat.Id, ChatAction.Typing);

                var keyboard = new InlineKeyboardMarkup(new[]
                {
                    
                        new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="پروژه مدیا پلیر ",
                           Url="https://fa.wikipedia.org/wiki/%D9%88%DB%8C%D9%86%D8%AF%D9%88%D8%B2_%D9%85%D8%AF%DB%8C%D8%A7_%D9%BE%D9%84%DB%8C%D8%B1"
                            }
                        },
                        new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="پروژه مدیا پلیر   ",
                           Url="http://mastercode.ir/payment.cshtml"
                            }
                        },
                          new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="پروژه ماتریس های دیترینگ ",
                           Url="http://webpages.iust.ac.ir/mehralian/files/courses/multimedia/chapter3.pdf"
                            }
                        },
                        new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="خرید ماتریس های دیترینگ ",
                           Url="http://mastercode.ir/payment.cshtml"
                            }
                        },
                          new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="پروژه تضاد رنگ ها ",
                           Url="http://webpages.iust.ac.ir/mehralian/files/courses/multimedia/chapter3.pdf"
                            }
                        },
                        new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="خرید پروژه  ",
                           Url="http://mastercode.ir/payment.cshtml"
                            }
                        },    
                });

                await Task.Delay(500);

                await Bot.SendTextMessageAsync(message.Chat.Id, "پروژه های موجود",
                    replyMarkup: keyboard);
            }
            else if (message.Text.StartsWith("/help")) 
            {
                var keyboard = new ReplyKeyboardMarkup(new[]
                {
                    new [] // first row
                    {
                        new KeyboardButton("/C++"),
                        new KeyboardButton("/C#"),
                        new KeyboardButton("/software_development"),
                    },
                    new [] // last row
                    {
                        new KeyboardButton("android"),
                        new KeyboardButton("/Managment"),  
                         new KeyboardButton("/sefaresh_narm_afzar"),
                    }
                });

                await Bot.SendTextMessageAsync(message.Chat.Id, "mozoat mojood",
                    replyMarkup: keyboard);
            }
            else if (message.Text.StartsWith("/C++"))
            {
                await Bot.SendChatActionAsync(message.Chat.Id, ChatAction.Typing);
                await Bot.SendTextMessageAsync(message.Chat.Id,message.From.FirstName+message.From.Username+message.From.Id);
            }
            else if (message.Text.StartsWith("/C#"))
            {
                await Bot.SendChatActionAsync(message.Chat.Id, ChatAction.Typing);

                var keyboard = new ReplyKeyboardMarkup(new[]
                {
                    new [] 
                    {
                        new KeyboardButton("/utility"),
                    },
                    new [] 
                    {
                        new KeyboardButton("/Operating-System"),
                    },
                    new [] 
                    {
                        new KeyboardButton("/Database"),
                    },
                    new [] 
                    {
                        new KeyboardButton("/Arificial-Intellingence"),
                    },
                    new [] 
                    {
                        new KeyboardButton("/Multimedia"),
                    },
                    new [] 
                    {
                         new KeyboardButton("/ASP.NET"),
                    },
                });
                
                await Bot.SendTextMessageAsync(message.Chat.Id, "پروژه های موجود",
                    replyMarkup: keyboard);
            }
            else if (message.Text.StartsWith("/sefaresh_narm_afzar")) 
            {
                
                
                var keyboardd = new InlineKeyboardMarkup(new[]
                {
                    
                        new InlineKeyboardButton[]
                        {
                            new InlineKeyboardButton{
                           Text="فرم ثبت سفارش",
                           Url="http://decasoft.ir/Order/order.cshtml"
                            }
                        }
                });
                await Task.Delay(500);
                await Bot.SendTextMessageAsync(message.Chat.Id, "rooye link zir click konid va form sefaresh ra por konid ya",
                    replyMarkup: keyboardd);
                var keyboard = new ReplyKeyboardMarkup(new[]
                {
                    new KeyboardButton("shomare")
                    {
                        RequestLocation = true
                    },
                    new KeyboardButton("adres")
                    {
                    
                        RequestContact = true
                    }, 
                   
                });


                await Bot.SendTextMessageAsync(message.Chat.Id, " shomare telephone va adres khod ra ba ma be eshterak begzareed ta ba shoma tamas gerefte shavad ya", replyMarkup: keyboard);

        }
        
            else
            {
                var usage = @"Usage:
dastor nadorost
/help ?
";

                await Bot.SendTextMessageAsync(message.Chat.Id, usage,
                    replyMarkup: new ReplyKeyboardHide());
            }
        }

        private static async void BotOnCallbackQueryReceived(object sender, CallbackQueryEventArgs callbackQueryEventArgs)
        {
             var message = callbackQueryEventArgs.CallbackQuery;
            await Bot.AnswerCallbackQueryAsync(callbackQueryEventArgs.CallbackQuery.Id,
                "Received {callbackQueryEventArgs.CallbackQuery.Data}");
          
        }
    }
}
